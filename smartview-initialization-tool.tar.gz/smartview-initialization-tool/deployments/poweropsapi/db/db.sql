-- MySQL dump 10.13  Distrib 8.0.32, for Linux (x86_64)
--
-- Host: localhost    Database: PowerOPS
-- ------------------------------------------------------
-- Server version       8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `device_mapping`
--

CREATE DATABASE IF NOT EXISTS `PowerOPS` default CHARSET utf8 COLLATE utf8_general_ci;

USE `PowerOPS`;

DROP TABLE IF EXISTS `device_mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `device_mapping` (
  `id` int NOT NULL AUTO_INCREMENT,
  `storage_id` int DEFAULT NULL,
  `switch_id` int DEFAULT NULL,
  `server_id` int DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `device_mapping`
--

LOCK TABLES `device_mapping` WRITE;
/*!40000 ALTER TABLE `device_mapping` DISABLE KEYS */;
/*!40000 ALTER TABLE `device_mapping` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exporters`
--

DROP TABLE IF EXISTS `exporters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `exporters` (
  `id` int NOT NULL AUTO_INCREMENT,
  `guid` varchar(100) DEFAULT NULL,
  `ip` varchar(100) DEFAULT NULL,
  `protocol` varchar(100) DEFAULT NULL,
  `protocol_port` int DEFAULT NULL,
  `user` varchar(100) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `type` varchar(100) DEFAULT NULL,
  `platform` varchar(100) DEFAULT NULL,
  `exporter_port` int DEFAULT NULL,
  `description` text,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exporters`
--

LOCK TABLES `exporters` WRITE;
/*!40000 ALTER TABLE `exporters` DISABLE KEYS */;
/*!40000 ALTER TABLE `exporters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `license`
--

DROP TABLE IF EXISTS `license`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `license` (
  `id` int NOT NULL AUTO_INCREMENT,
  `node_info` text,
  `machine_key` text,
  `licensed_node_count` int DEFAULT NULL,
  `license_code` varchar(100) DEFAULT NULL,
  `expiration` datetime DEFAULT NULL,
  `type` varchar(100) DEFAULT NULL,
  `status` varchar(128) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `license`
--

LOCK TABLES `license` WRITE;
/*!40000 ALTER TABLE `license` DISABLE KEYS */;
/*!40000 ALTER TABLE `license` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `license_code`
--

DROP TABLE IF EXISTS `license_code`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `license_code` (
  `id` int NOT NULL AUTO_INCREMENT,
  `license_code` varchar(100) DEFAULT NULL,
  `service_tag` varchar(100) DEFAULT NULL,
  `cpu_id` varchar(100) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `license_code`
--

LOCK TABLES `license_code` WRITE;
/*!40000 ALTER TABLE `license_code` DISABLE KEYS */;
/*!40000 ALTER TABLE `license_code` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `monitor_dashboard_setting`
--

DROP TABLE IF EXISTS `monitor_dashboard_setting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `monitor_dashboard_setting` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `category` int DEFAULT NULL,
  `type` varchar(20) DEFAULT NULL,
  `in_use` int DEFAULT NULL,
  `value` text,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `monitor_dashboard_setting`
--

LOCK TABLES `monitor_dashboard_setting` WRITE;
/*!40000 ALTER TABLE `monitor_dashboard_setting` DISABLE KEYS */;
INSERT INTO `monitor_dashboard_setting` VALUES (1,'default',1,'default',1,'[{\"name\":\"System Overview\",\"show\":true,\"navHide\":true,\"height\":200,\"mode\":\"card\",\"mbList\":[{\"key\":\"k0004\",\"left\":0,\"top\":0,\"width\":3,\"height\":1,\"type\":\"txt\",\"name\":\"Cluster Health\",\"value\":\"\",\"interval\":300,\"lastUpdate\":0,\"fontSize\":32,\"fontColor\":\"#0076ce\"},{\"key\":\"k0005\",\"left\":3,\"top\":0,\"width\":9,\"height\":1,\"type\":\"bargauge\",\"name\":\"Cluster Capacity\",\"interval\":300,\"lastUpdate\":0,\"fontSize\":18,\"fontColor\":\"#0076ce\",\"value\":{\"keys\":[\"\"],\"values\":[0],\"maxData\":100,\"valueUnit\":\"GiB\",\"unit\":\"%\"},\"thresholds\":[{\"mode\":\"ok\",\"min\":\"0\",\"max\":\"70\"},{\"mode\":\"warning\",\"min\":\"70\",\"max\":\"85\"},{\"mode\":\"critical\",\"min\":\"85\",\"max\":\"100\"}]},{\"key\":\"k0006\",\"left\":12,\"top\":0,\"width\":9,\"height\":1,\"type\":\"bargauge\",\"name\":\"System Utilization\",\"interval\":300,\"lastUpdate\":0,\"fontSize\":18,\"fontColor\":\"#0076ce\",\"value\":{\"keys\":[\"\"],\"values\":[0],\"maxData\":100,\"unit\":\"%\"},\"thresholds\":[{\"mode\":\"ok\",\"min\":\"0\",\"max\":\"70\"},{\"mode\":\"warning\",\"min\":\"70\",\"max\":\"85\"},{\"mode\":\"critical\",\"min\":\"85\",\"max\":\"100\"}]},{\"key\":\"k0009\",\"left\":21,\"top\":0,\"width\":3,\"height\":1,\"type\":\"txt\",\"name\":\"Cluster Alerts\",\"interval\":300,\"lastUpdate\":0,\"fontSize\":32,\"fontColor\":\"#0076ce\",\"value\":\"\"},{\"key\":\"k0014\",\"left\":0,\"top\":1,\"width\":12,\"height\":1,\"type\":\"bargauge\",\"name\":\"Cluster Efficiency Ratio\",\"interval\":300,\"lastUpdate\":0,\"fontSize\":18,\"fontColor\":\"#0076ce\",\"value\":{\"keys\":[\"\"],\"values\":[0],\"maxData\":100,\"unit\":\"%\"}},{\"key\":\"k0015\",\"left\":0,\"top\":2,\"width\":4,\"height\":1,\"type\":\"txt\",\"name\":\"Chasis Count\",\"interval\":300,\"lastUpdate\":0,\"fontSize\":30,\"fontColor\":\"#0076ce\",\"value\":\"\"},{\"key\":\"k0016\",\"left\":4,\"top\":2,\"width\":4,\"height\":1,\"type\":\"txt\",\"name\":\"Cluster FS Throughput\",\"interval\":300,\"lastUpdate\":0,\"fontSize\":30,\"fontColor\":\"#0076ce\",\"value\":\"\"},{\"key\":\"k0017\",\"left\":8,\"top\":2,\"width\":4,\"height\":1,\"type\":\"txt\",\"name\":\"Cluster FS OPS\",\"interval\":300,\"lastUpdate\":0,\"fontSize\":30,\"fontColor\":\"#0076ce\",\"value\":\"\"},{\"key\":\"k0018\",\"left\":12,\"top\":1,\"width\":12,\"height\":2,\"type\":\"bargauge\",\"name\":\"Active client Connections\",\"interval\":300,\"lastUpdate\":0,\"fontSize\":18,\"fontColor\":\"#0076ce\",\"value\":{\"keys\":[\"NFS\",\"SMB\",\"SIQ\"],\"values\":[0,0,0],\"maxData\":100,\"unit\":\"\"}}]},{\"name\":\"Attention\",\"show\":true,\"navHide\":true,\"height\":200,\"mode\":\"attention\",\"mbList\":[]},{\"name\":\"System\",\"show\":false,\"height\":200,\"mode\":\"card\",\"mbList\":[],\"children\":[{\"name\":\"System Information\",\"show\":false,\"height\":200,\"mode\":\"card\",\"mbList\":[{\"key\":\"k0001\",\"left\":0,\"top\":0,\"width\":4,\"height\":1,\"type\":\"txt\",\"name\":\"Cluster ID\",\"value\":\"\",\"interval\":\"0\",\"lastUpdate\":0,\"fontSize\":13,\"fontColor\":\"#0076ce\"},{\"key\":\"k0002\",\"left\":4,\"top\":0,\"width\":4,\"height\":1,\"type\":\"txt\",\"name\":\"Cluster Name\",\"value\":\"\",\"interval\":0,\"lastUpdate\":0,\"fontSize\":18,\"fontColor\":\"#0076ce\"},{\"key\":\"k0003\",\"left\":8,\"top\":0,\"width\":4,\"height\":1,\"type\":\"txt\",\"name\":\"Onefs Version\",\"value\":\"\",\"interval\":0,\"lastUpdate\":0,\"fontSize\":18,\"fontColor\":\"#0076ce\"},{\"key\":\"k0010\",\"left\":12,\"top\":0,\"width\":4,\"height\":1,\"type\":\"txt\",\"name\":\"Cluster Encoding\",\"interval\":0,\"lastUpdate\":0,\"fontSize\":18,\"fontColor\":\"#0076ce\",\"value\":\"\"},{\"key\":\"k0011\",\"left\":16,\"top\":0,\"width\":4,\"height\":1,\"type\":\"txt\",\"name\":\"Cluster IsVirtual\",\"interval\":0,\"lastUpdate\":0,\"fontSize\":18,\"fontColor\":\"#0076ce\",\"value\":\"\"},{\"key\":\"k0012\",\"left\":20,\"top\":0,\"width\":2,\"height\":1,\"type\":\"txt\",\"name\":\"Node Count\",\"interval\":0,\"lastUpdate\":0,\"fontSize\":18,\"fontColor\":\"#0076ce\",\"value\":\"\"},{\"key\":\"k0013\",\"left\":22,\"top\":0,\"width\":2,\"height\":1,\"type\":\"txt\",\"name\":\"Node Up Count\",\"interval\":300,\"lastUpdate\":0,\"fontSize\":18,\"fontColor\":\"#0076ce\",\"value\":\"\"},{\"key\":\"k0019\",\"left\":0,\"top\":1,\"width\":12,\"height\":3,\"type\":\"table\",\"name\":\"Cluster Mgmt External IPs\",\"interval\":300,\"lastUpdate\":0,\"fontSize\":18,\"fontColor\":\"#0076ce\",\"value\":{\"keys\":[{\"prop\":\"type\",\"label\":\"Type\"},{\"prop\":\"name\",\"label\":\"Name\"},{\"prop\":\"ip_addrs\",\"label\":\"IP Address\"},{\"prop\":\"status\",\"label\":\"Status\"}],\"values\":[]}},{\"key\":\"k0020\",\"left\":12,\"top\":1,\"width\":12,\"height\":3,\"type\":\"table\",\"name\":\"Cluster Internal Networks\",\"interval\":300,\"lastUpdate\":0,\"fontSize\":18,\"fontColor\":\"#0076ce\",\"value\":{\"keys\":[{\"prop\":\"fabric\",\"label\":\"Fabric\"},{\"prop\":\"type\",\"label\":\"Type\"},{\"prop\":\"status\",\"label\":\"Status\"},{\"prop\":\"len\",\"label\":\"IP Prefix Length\"},{\"prop\":\"ip_addresses\",\"label\":\"IP Addresses\"}],\"values\":[]}},{\"key\":\"k0021\",\"left\":0,\"top\":4,\"width\":24,\"height\":3,\"type\":\"table\",\"name\":\"License\",\"value\":{\"keys\":[{\"prop\":\"id\",\"label\":\"ID\"},{\"prop\":\"name\",\"label\":\"Name\"},{\"prop\":\"licensed_node_count\",\"label\":\"Licensed Node Count\"},{\"prop\":\"used_node_count\",\"label\":\"Used Node Count\"},{\"prop\":\"tier\",\"label\":\"Tier\"},{\"prop\":\"status\",\"label\":\"Status\"}],\"values\":[]},\"interval\":0,\"lastUpdate\":0}]},{\"name\":\"Snapshots Information\",\"show\":false,\"height\":200,\"mode\":\"card\",\"mbList\":[{\"key\":\"sxi0001\",\"left\":0,\"top\":0,\"width\":24,\"height\":4,\"type\":\"table\",\"name\":\"Snapshots\",\"interval\":300,\"lastUpdate\":0,\"fontSize\":32,\"fontColor\":\"#0076ce\",\"value\":{\"keys\":[{\"prop\":\"id\",\"label\":\"ID\"},{\"prop\":\"name\",\"label\":\"Name\"},{\"prop\":\"path\",\"label\":\"Path\"},{\"prop\":\"state\",\"label\":\"State\"},{\"prop\":\"expires\",\"label\":\"Expires\"},{\"prop\":\"size\",\"label\":\"Size\"}],\"values\":[]}}]},{\"name\":\"Storage Pool Information\",\"show\":false,\"height\":200,\"mode\":\"card\",\"mbList\":[{\"key\":\"sxi0002\",\"left\":0,\"top\":0,\"width\":6,\"height\":3,\"type\":\"pie\",\"name\":\"Storage Pool Capacity\",\"interval\":300,\"lastUpdate\":0,\"fontSize\":32,\"fontColor\":\"#0076ce\",\"value\":{\"unit\":\"B\",\"values\":[]}},{\"key\":\"sxi0003\",\"left\":6,\"top\":0,\"width\":6,\"height\":3,\"type\":\"gauge\",\"name\":\"Storage Pool SSD Percent\",\"interval\":300,\"lastUpdate\":0,\"fontSize\":32,\"fontColor\":\"#0076ce\",\"value\":{\"value\":25,\"unit\":\"%\",\"color\":\"#0076ce\",\"min\":0,\"max\":100,\"splitNumber\":5}},{\"key\":\"sxi0004\",\"left\":12,\"top\":0,\"width\":4,\"height\":3,\"type\":\"txt\",\"name\":\"Storage Pool Total Capacity\",\"value\":\"\",\"interval\":300,\"lastUpdate\":0,\"fontSize\":64,\"fontColor\":\"#0076ce\"},{\"key\":\"sxi0005\",\"left\":16,\"top\":0,\"width\":4,\"height\":3,\"type\":\"txt\",\"name\":\"Storage Pool Type\",\"value\":\"\",\"interval\":300,\"lastUpdate\":0,\"fontSize\":64,\"fontColor\":\"#0076ce\"},{\"key\":\"sxi0006\",\"left\":20,\"top\":0,\"width\":4,\"height\":3,\"type\":\"txt\",\"name\":\"Storage Pool Protection Policy\",\"value\":\"\",\"interval\":300,\"lastUpdate\":0,\"fontSize\":64,\"fontColor\":\"#0076ce\"},{\"key\":\"sxi0007\",\"left\":0,\"top\":3,\"width\":24,\"height\":3,\"type\":\"table\",\"name\":\"Storage Pool LNNs\",\"interval\":300,\"lastUpdate\":0,\"fontSize\":32,\"fontColor\":\"#0076ce\",\"value\":{\"keys\":[{\"prop\":\"container\",\"label\":\"Container\"},{\"prop\":\"endpoint\",\"label\":\"Endpoint\"},{\"prop\":\"instance\",\"label\":\"Instance\"},{\"prop\":\"job\",\"label\":\"Job\"},{\"prop\":\"lnn\",\"label\":\"Node\"},{\"prop\":\"name\",\"label\":\"Name\"},{\"prop\":\"namespace\",\"label\":\"Namespace\"},{\"prop\":\"pod\",\"label\":\"Pod\"},{\"prop\":\"service\",\"label\":\"Service\"},{\"prop\":\"type\",\"label\":\"Type\"}],\"values\":[]}}]},{\"name\":\"SyncIQ Information\",\"show\":false,\"height\":200,\"mode\":\"card\",\"mbList\":[{\"key\":\"sxi0008\",\"left\":0,\"top\":0,\"width\":10,\"height\":2,\"type\":\"table\",\"name\":\"SyncIQ Policy\",\"interval\":300,\"lastUpdate\":0,\"fontSize\":32,\"fontColor\":\"#0076ce\",\"value\":{\"keys\":[{\"prop\":\"xx\",\"label\":\"xx\"}],\"values\":[]}},{\"key\":\"sxi0009\",\"left\":10,\"top\":0,\"width\":10,\"height\":4,\"type\":\"table\",\"name\":\"SyncIQ Worker\",\"interval\":300,\"lastUpdate\":0,\"fontSize\":32,\"fontColor\":\"#0076ce\",\"value\":{\"keys\":[{\"prop\":\"xx\",\"label\":\"xx\"}],\"values\":[]}},{\"key\":\"sxi0010\",\"left\":20,\"top\":0,\"width\":4,\"height\":4,\"type\":\"txt\",\"name\":\"SyncIQ Bandwidth\",\"value\":\"\",\"interval\":300,\"lastUpdate\":0,\"fontSize\":32,\"fontColor\":\"#0076ce\"},{\"key\":\"sxi0011\",\"left\":0,\"top\":2,\"width\":10,\"height\":2,\"type\":\"txt\",\"name\":\"SyncIQ Job\",\"value\":\"\",\"interval\":300,\"lastUpdate\":0,\"fontSize\":32,\"fontColor\":\"#0076ce\"}]}]},{\"name\":\"Hardware\",\"show\":false,\"height\":200,\"mode\":\"hardware\",\"mbList\":[]},{\"name\":\"Performance\",\"show\":false,\"height\":200,\"mode\":\"card\",\"mbList\":[],\"children\":[{\"name\":\"Performance-System\",\"show\":false,\"height\":200,\"mode\":\"card\",\"mbList\":[{\"key\":\"ps0001\",\"left\":0,\"top\":0,\"width\":12,\"height\":4,\"type\":\"line\",\"name\":\"System CPU Usage\",\"interval\":\"600\",\"lastUpdate\":0,\"fontSize\":18,\"fontColor\":\"#0076ce\",\"step\":60,\"value\":{\"unit\":\"%\",\"interval\":null,\"values\":[{\"type\":\"line\",\"showSymbol\":false,\"data\":[],\"lineStyle\":{\"normal\":{\"width\":1}},\"itemStyle\":{\"color\":\"rgb(103,194,58)\"},\"areaStyle\":{\"color\":\"rgba(103,194,58,0.2)\"}}],\"xAxisData\":[]},\"thresholds\":[{\"mode\":\"warning\",\"min\":\"5\",\"max\":\"50\",\"unit\":[\"%\"]}]},{\"key\":\"ps0002\",\"left\":12,\"top\":0,\"width\":12,\"height\":2,\"type\":\"line\",\"name\":\"System Net Input\",\"interval\":300,\"lastUpdate\":0,\"fontSize\":18,\"fontColor\":\"#0076ce\",\"step\":60,\"value\":{\"unit\":\"KB/s\",\"interval\":null,\"values\":[{\"type\":\"line\",\"showSymbol\":false,\"data\":[],\"lineStyle\":{\"normal\":{\"width\":1}},\"itemStyle\":{\"color\":\"rgb(103,194,58)\"},\"areaStyle\":{\"color\":\"rgba(103,194,58,0.2)\"}}],\"xAxisData\":[]},\"thresholds\":[{\"mode\":\"warning\",\"min\":\"0\",\"max\":\"10\",\"unit\":[\"Byte/sec\",\"MB/s\"]}]},{\"key\":\"ps0003\",\"left\":12,\"top\":2,\"width\":12,\"height\":2,\"type\":\"line\",\"name\":\"System Net Output\",\"interval\":300,\"lastUpdate\":0,\"fontSize\":18,\"fontColor\":\"#0076ce\",\"step\":60,\"value\":{\"unit\":\"KB/s\",\"interval\":null,\"values\":[{\"type\":\"line\",\"showSymbol\":false,\"data\":[],\"lineStyle\":{\"normal\":{\"width\":1}},\"itemStyle\":{\"color\":\"rgb(103,194,58)\"},\"areaStyle\":{\"color\":\"rgba(103,194,58,0.2)\"}}],\"xAxisData\":[]},\"thresholds\":[{\"mode\":\"warning\",\"min\":\"20\",\"max\":\"200\",\"unit\":[\"Byte/sec\",\"KB/s\"]}]},{\"key\":\"ps0004\",\"left\":0,\"top\":4,\"width\":12,\"height\":3,\"type\":\"line\",\"name\":\"System Disk Input\",\"interval\":300,\"lastUpdate\":0,\"fontSize\":18,\"fontColor\":\"#0076ce\",\"step\":60,\"value\":{\"unit\":\"KB/s\",\"interval\":null,\"values\":[{\"type\":\"line\",\"showSymbol\":false,\"data\":[],\"lineStyle\":{\"normal\":{\"width\":1}},\"itemStyle\":{\"color\":\"rgb(103,194,58)\"},\"areaStyle\":{\"color\":\"rgba(103,194,58,0.2)\"}}],\"xAxisData\":[]},\"thresholds\":[]},{\"key\":\"ps0005\",\"left\":12,\"top\":4,\"width\":12,\"height\":3,\"type\":\"line\",\"name\":\"System Disk Output\",\"interval\":300,\"lastUpdate\":0,\"fontSize\":18,\"fontColor\":\"#0076ce\",\"step\":60,\"value\":{\"unit\":\"KB/s\",\"interval\":null,\"values\":[{\"type\":\"line\",\"showSymbol\":false,\"data\":[],\"lineStyle\":{\"normal\":{\"width\":1}},\"itemStyle\":{\"color\":\"rgb(103,194,58)\"},\"areaStyle\":{\"color\":\"rgba(103,194,58,0.2)\"}}],\"xAxisData\":[]},\"thresholds\":[]},{\"key\":\"ps0006\",\"left\":0,\"top\":7,\"width\":24,\"height\":2,\"type\":\"gaugemult\",\"name\":\"Node\'s Disk Busy\",\"interval\":300,\"lastUpdate\":0,\"fontSize\":18,\"fontColor\":\"#0076ce\",\"value\":{\"chartsNum\":10}},{\"key\":\"ps0007\",\"left\":0,\"top\":9,\"width\":10,\"height\":2,\"type\":\"line\",\"name\":\"System NFS Input Bandwidth\",\"interval\":300,\"lastUpdate\":0,\"fontSize\":18,\"fontColor\":\"#0076ce\",\"step\":60,\"value\":{\"unit\":\"KB/s\",\"interval\":null,\"values\":[{\"type\":\"line\",\"showSymbol\":false,\"data\":[],\"lineStyle\":{\"normal\":{\"width\":1}},\"itemStyle\":{\"color\":\"rgb(103,194,58)\"},\"areaStyle\":{\"color\":\"rgba(103,194,58,0.2)\"}}],\"xAxisData\":[]},\"thresholds\":[]},{\"key\":\"ps0008\",\"left\":10,\"top\":9,\"width\":10,\"height\":2,\"type\":\"line\",\"name\":\"System NFS Output Bandwidth\",\"interval\":300,\"lastUpdate\":0,\"fontSize\":18,\"fontColor\":\"#0076ce\",\"step\":60,\"value\":{\"unit\":\"KB/s\",\"interval\":null,\"values\":[{\"type\":\"line\",\"showSymbol\":false,\"data\":[],\"lineStyle\":{\"normal\":{\"width\":1}},\"itemStyle\":{\"color\":\"rgb(103,194,58)\"},\"areaStyle\":{\"color\":\"rgba(103,194,58,0.2)\"}}],\"xAxisData\":[]},\"thresholds\":[]},{\"key\":\"ps0009\",\"left\":20,\"top\":9,\"width\":4,\"height\":2,\"type\":\"txt\",\"name\":\"System NFS OPS\",\"interval\":300,\"lastUpdate\":0,\"fontSize\":36,\"fontColor\":\"#0076ce\",\"value\":\"\"},{\"key\":\"ps0010\",\"left\":0,\"top\":11,\"width\":10,\"height\":2,\"type\":\"line\",\"name\":\"System SMB Input Bandwidth\",\"interval\":300,\"lastUpdate\":0,\"fontSize\":18,\"fontColor\":\"#0076ce\",\"step\":60,\"value\":{\"unit\":\"KB/s\",\"interval\":null,\"values\":[{\"type\":\"line\",\"showSymbol\":false,\"data\":[],\"lineStyle\":{\"normal\":{\"width\":1}},\"itemStyle\":{\"color\":\"rgb(103,194,58)\"},\"areaStyle\":{\"color\":\"rgba(103,194,58,0.2)\"}}],\"xAxisData\":[]},\"thresholds\":[]},{\"key\":\"ps0011\",\"left\":10,\"top\":11,\"width\":10,\"height\":2,\"type\":\"line\",\"name\":\"System SMB Output Bandwidth\",\"interval\":300,\"lastUpdate\":0,\"fontSize\":18,\"fontColor\":\"#0076ce\",\"step\":60,\"value\":{\"unit\":\"KB/s\",\"interval\":null,\"values\":[{\"type\":\"line\",\"showSymbol\":false,\"data\":[],\"lineStyle\":{\"normal\":{\"width\":1}},\"itemStyle\":{\"color\":\"rgb(103,194,58)\"},\"areaStyle\":{\"color\":\"rgba(103,194,58,0.2)\"}}],\"xAxisData\":[]},\"thresholds\":[]},{\"key\":\"ps0012\",\"left\":20,\"top\":11,\"width\":4,\"height\":2,\"type\":\"txt\",\"name\":\"System SMB OPS\",\"interval\":300,\"lastUpdate\":0,\"fontSize\":36,\"fontColor\":\"#0076ce\",\"value\":\"\"},{\"key\":\"ps0013\",\"left\":0,\"top\":13,\"width\":10,\"height\":2,\"type\":\"line\",\"name\":\"System HTTP Input Bandwidth\",\"interval\":300,\"lastUpdate\":0,\"fontSize\":18,\"fontColor\":\"#0076ce\",\"step\":60,\"value\":{\"unit\":\"KB/s\",\"interval\":null,\"values\":[{\"type\":\"line\",\"showSymbol\":false,\"data\":[],\"lineStyle\":{\"normal\":{\"width\":1}},\"itemStyle\":{\"color\":\"rgb(103,194,58)\"},\"areaStyle\":{\"color\":\"rgba(103,194,58,0.2)\"}}],\"xAxisData\":[]},\"thresholds\":[]},{\"key\":\"ps0014\",\"left\":10,\"top\":13,\"width\":10,\"height\":2,\"type\":\"line\",\"name\":\"System HTTP Output Bandwidth\",\"interval\":300,\"lastUpdate\":0,\"fontSize\":18,\"fontColor\":\"#0076ce\",\"step\":60,\"value\":{\"unit\":\"KB/s\",\"interval\":null,\"values\":[{\"type\":\"line\",\"showSymbol\":false,\"data\":[],\"lineStyle\":{\"normal\":{\"width\":1}},\"itemStyle\":{\"color\":\"rgb(103,194,58)\"},\"areaStyle\":{\"color\":\"rgba(103,194,58,0.2)\"}}],\"xAxisData\":[]},\"thresholds\":[]},{\"key\":\"ps0015\",\"left\":20,\"top\":13,\"width\":4,\"height\":2,\"type\":\"txt\",\"name\":\"System HTTP OPS\",\"interval\":300,\"lastUpdate\":0,\"fontSize\":36,\"fontColor\":\"#0076ce\",\"value\":\"\"},{\"key\":\"ps0016\",\"left\":0,\"top\":15,\"width\":10,\"height\":2,\"type\":\"line\",\"name\":\"System FTP Input Bandwidth\",\"interval\":300,\"lastUpdate\":0,\"fontSize\":18,\"fontColor\":\"#0076ce\",\"step\":60,\"value\":{\"unit\":\"KB/s\",\"interval\":null,\"values\":[{\"type\":\"line\",\"showSymbol\":false,\"data\":[],\"lineStyle\":{\"normal\":{\"width\":1}},\"itemStyle\":{\"color\":\"rgb(103,194,58)\"},\"areaStyle\":{\"color\":\"rgba(103,194,58,0.2)\"}}],\"xAxisData\":[]},\"thresholds\":[]},{\"key\":\"ps0017\",\"left\":10,\"top\":15,\"width\":10,\"height\":2,\"type\":\"line\",\"name\":\"System FTP Output Bandwidth\",\"interval\":300,\"lastUpdate\":0,\"fontSize\":18,\"fontColor\":\"#0076ce\",\"step\":60,\"value\":{\"unit\":\"KB/s\",\"interval\":null,\"values\":[{\"type\":\"line\",\"showSymbol\":false,\"data\":[],\"lineStyle\":{\"normal\":{\"width\":1}},\"itemStyle\":{\"color\":\"rgb(103,194,58)\"},\"areaStyle\":{\"color\":\"rgba(103,194,58,0.2)\"}}],\"xAxisData\":[]},\"thresholds\":[]},{\"key\":\"ps0018\",\"left\":20,\"top\":15,\"width\":4,\"height\":2,\"type\":\"txt\",\"name\":\"System FTP OPS\",\"interval\":300,\"lastUpdate\":0,\"fontSize\":36,\"fontColor\":\"#0076ce\",\"value\":\"\"},{\"key\":\"ps0019\",\"left\":0,\"top\":17,\"width\":10,\"height\":2,\"type\":\"line\",\"name\":\"System HDFS Input Bandwidth\",\"interval\":300,\"lastUpdate\":0,\"fontSize\":18,\"fontColor\":\"#0076ce\",\"step\":60,\"value\":{\"unit\":\"KB/s\",\"interval\":null,\"values\":[{\"type\":\"line\",\"showSymbol\":false,\"data\":[],\"lineStyle\":{\"normal\":{\"width\":1}},\"itemStyle\":{\"color\":\"rgb(103,194,58)\"},\"areaStyle\":{\"color\":\"rgba(103,194,58,0.2)\"}}],\"xAxisData\":[]},\"thresholds\":[]},{\"key\":\"ps0020\",\"left\":10,\"top\":17,\"width\":10,\"height\":2,\"type\":\"line\",\"name\":\"System HDFS Output Bandwidth\",\"interval\":300,\"lastUpdate\":0,\"fontSize\":18,\"fontColor\":\"#0076ce\",\"step\":60,\"value\":{\"unit\":\"KB/s\",\"interval\":null,\"values\":[{\"type\":\"line\",\"showSymbol\":false,\"data\":[],\"lineStyle\":{\"normal\":{\"width\":1}},\"itemStyle\":{\"color\":\"rgb(103,194,58)\"},\"areaStyle\":{\"color\":\"rgba(103,194,58,0.2)\"}}],\"xAxisData\":[]},\"thresholds\":[]},{\"key\":\"ps0021\",\"left\":20,\"top\":17,\"width\":4,\"height\":2,\"type\":\"txt\",\"name\":\"System HDFS OPS\",\"interval\":300,\"lastUpdate\":0,\"fontSize\":36,\"fontColor\":\"#0076ce\",\"value\":\"\"}]},{\"name\":\"Performance-Network\",\"show\":false,\"height\":200,\"mode\":\"card\",\"mbList\":[{\"key\":\"pp0001\",\"left\":0,\"top\":0,\"width\":6,\"height\":2,\"type\":\"line\",\"name\":\"External Network Interface Input Bandwidth\",\"interval\":300,\"lastUpdate\":0,\"fontSize\":64,\"fontColor\":\"#0076ce\",\"step\":60,\"value\":{\"unit\":\"KB/s\",\"values\":[{\"type\":\"line\",\"showSymbol\":false,\"data\":[],\"lineStyle\":{\"normal\":{\"width\":1}},\"itemStyle\":{\"color\":\"rgb(103,194,58)\"},\"areaStyle\":{\"color\":\"rgba(103,194,58,0.2)\"}}],\"xAxisData\":[]},\"thresholds\":[]},{\"key\":\"pp0002\",\"left\":6,\"top\":0,\"width\":6,\"height\":2,\"type\":\"line\",\"name\":\"External Network Interface Output Bandwidth\",\"interval\":300,\"lastUpdate\":0,\"fontSize\":64,\"fontColor\":\"#0076ce\",\"step\":60,\"value\":{\"unit\":\"B/s\",\"values\":[{\"type\":\"line\",\"showSymbol\":false,\"data\":[],\"lineStyle\":{\"normal\":{\"width\":1}},\"itemStyle\":{\"color\":\"rgb(230,162,60)\"},\"areaStyle\":{\"color\":\"rgba(230,162,60,0.2)\"}}],\"xAxisData\":[]},\"thresholds\":[]},{\"key\":\"pp0003\",\"left\":12,\"top\":0,\"width\":6,\"height\":2,\"type\":\"line\",\"name\":\"External Network Interface Errors Intput Bandwidth\",\"interval\":300,\"lastUpdate\":0,\"fontSize\":64,\"fontColor\":\"#0076ce\",\"step\":60,\"value\":{\"unit\":\"c/s\",\"values\":[{\"type\":\"line\",\"showSymbol\":false,\"data\":[],\"lineStyle\":{\"normal\":{\"width\":1}},\"itemStyle\":{\"color\":\"rgb(245,108,108)\"},\"areaStyle\":{\"color\":\"rgba(245,108,108,0.2)\"}}],\"xAxisData\":[]},\"thresholds\":[]},{\"key\":\"pp0004\",\"left\":18,\"top\":0,\"width\":6,\"height\":2,\"type\":\"line\",\"name\":\"External Network Interface Errors Output Bandwidth\",\"interval\":300,\"lastUpdate\":0,\"fontSize\":64,\"fontColor\":\"#0076ce\",\"step\":60,\"value\":{\"unit\":\"c/s\",\"values\":[{\"type\":\"line\",\"showSymbol\":false,\"data\":[],\"lineStyle\":{\"normal\":{\"width\":1}},\"itemStyle\":{\"color\":\"rgb(103,194,58)\"},\"areaStyle\":{\"color\":\"rgba(103,194,58,0.2)\"}}],\"xAxisData\":[]},\"thresholds\":[]}]},{\"name\":\"Performance-Protocol\",\"show\":false,\"height\":200,\"mode\":\"card\",\"mbList\":[{\"key\":\"pn0001\",\"left\":0,\"top\":0,\"width\":6,\"height\":2,\"type\":\"line\",\"name\":\"Protocol HTTP OPS\",\"interval\":300,\"lastUpdate\":0,\"fontSize\":64,\"fontColor\":\"#0076ce\",\"step\":60,\"value\":{\"unit\":\"ops/s\",\"values\":[{\"type\":\"line\",\"showSymbol\":false,\"data\":[],\"lineStyle\":{\"color\":\"#0076ce\",\"normal\":{\"width\":1}},\"areaStyle\":{\"color\":\"#3eaafa\"}}],\"xAxisData\":[]},\"thresholds\":[]},{\"key\":\"pn0002\",\"left\":6,\"top\":0,\"width\":6,\"height\":2,\"type\":\"line\",\"name\":\"Protocol NFS OPS\",\"interval\":300,\"lastUpdate\":0,\"fontSize\":64,\"fontColor\":\"#0076ce\",\"step\":60,\"value\":{\"unit\":\"ops/s\",\"values\":[{\"type\":\"line\",\"showSymbol\":false,\"data\":[],\"lineStyle\":{\"color\":\"#0076ce\",\"normal\":{\"width\":1}},\"areaStyle\":{\"color\":\"#3eaafa\"}}],\"xAxisData\":[]},\"thresholds\":[]},{\"key\":\"pn0003\",\"left\":12,\"top\":0,\"width\":6,\"height\":2,\"type\":\"line\",\"name\":\"Protocol HDFS OPS\",\"interval\":300,\"lastUpdate\":0,\"fontSize\":64,\"fontColor\":\"#0076ce\",\"step\":60,\"value\":{\"unit\":\"ops/s\",\"values\":[{\"type\":\"line\",\"showSymbol\":false,\"data\":[],\"lineStyle\":{\"color\":\"#0076ce\",\"normal\":{\"width\":1}},\"areaStyle\":{\"color\":\"#3eaafa\"}}],\"xAxisData\":[]},\"thresholds\":[]},{\"key\":\"pn0004\",\"left\":18,\"top\":0,\"width\":6,\"height\":2,\"type\":\"line\",\"name\":\"Protocol SMB OPS\",\"interval\":300,\"lastUpdate\":0,\"fontSize\":64,\"fontColor\":\"#0076ce\",\"step\":60,\"value\":{\"unit\":\"ops/s\",\"values\":[{\"type\":\"line\",\"showSymbol\":false,\"data\":[],\"lineStyle\":{\"color\":\"#0076ce\",\"normal\":{\"width\":1}},\"areaStyle\":{\"color\":\"#3eaafa\"}}],\"xAxisData\":[]},\"thresholds\":[]},{\"key\":\"pn0005\",\"left\":0,\"top\":2,\"width\":6,\"height\":2,\"type\":\"line\",\"name\":\"Protocol HTTP Bandwidth\",\"interval\":300,\"lastUpdate\":0,\"fontSize\":64,\"fontColor\":\"#0076ce\",\"step\":60,\"value\":{\"unit\":\"B/s\",\"values\":[{\"type\":\"line\",\"showSymbol\":false,\"data\":[],\"lineStyle\":{\"color\":\"#0076ce\",\"normal\":{\"width\":1}},\"areaStyle\":{\"color\":\"#3eaafa\"}}],\"xAxisData\":[]},\"thresholds\":[]},{\"key\":\"pn0006\",\"left\":6,\"top\":2,\"width\":6,\"height\":2,\"type\":\"line\",\"name\":\"Protocol NFS Bandwidth\",\"interval\":300,\"lastUpdate\":0,\"fontSize\":64,\"fontColor\":\"#0076ce\",\"step\":60,\"value\":{\"unit\":\"B/s\",\"values\":[{\"type\":\"line\",\"showSymbol\":false,\"data\":[],\"lineStyle\":{\"color\":\"#0076ce\",\"normal\":{\"width\":1}},\"areaStyle\":{\"color\":\"#3eaafa\"}}],\"xAxisData\":[]},\"thresholds\":[]},{\"key\":\"pn0007\",\"left\":12,\"top\":2,\"width\":6,\"height\":2,\"type\":\"line\",\"name\":\"Protocol HDFS Bandwidth\",\"interval\":300,\"lastUpdate\":0,\"fontSize\":64,\"fontColor\":\"#0076ce\",\"step\":60,\"value\":{\"unit\":\"B/s\",\"values\":[{\"type\":\"line\",\"showSymbol\":false,\"data\":[],\"lineStyle\":{\"color\":\"#0076ce\",\"normal\":{\"width\":1}},\"areaStyle\":{\"color\":\"#3eaafa\"}}],\"xAxisData\":[]},\"thresholds\":[]},{\"key\":\"pn0008\",\"left\":18,\"top\":2,\"width\":6,\"height\":2,\"type\":\"line\",\"name\":\"Protocol SMB Bandwidth\",\"interval\":300,\"lastUpdate\":0,\"fontSize\":64,\"fontColor\":\"#0076ce\",\"step\":60,\"value\":{\"unit\":\"B/s\",\"values\":[{\"type\":\"line\",\"showSymbol\":false,\"data\":[],\"lineStyle\":{\"color\":\"#0076ce\",\"normal\":{\"width\":1}},\"areaStyle\":{\"color\":\"#3eaafa\"}}],\"xAxisData\":[]},\"thresholds\":[]}]}]},{\"name\":\"Client\",\"show\":false,\"height\":200,\"mode\":\"card\",\"mbList\":[],\"children\":[]},{\"name\":\"Events\",\"show\":false,\"height\":200,\"mode\":\"card\",\"mbList\":[{\"key\":\"at0001\",\"left\":0,\"top\":0,\"width\":24,\"height\":4,\"type\":\"table\",\"name\":\"Events List\",\"interval\":300,\"lastUpdate\":0,\"fontSize\":18,\"fontColor\":\"#0076ce\",\"value\":{\"keys\":[{\"prop\":\"id\",\"label\":\"ID\"},{\"prop\":\"severity\",\"label\":\"Severity\"},{\"prop\":\"lnn\",\"label\":\"Node\"},{\"prop\":\"eventgroup_instance\",\"label\":\"EventGroup Instance\"},{\"prop\":\"time1\",\"label\":\"Event Time\",\"sortable\":true},{\"prop\":\"resolve_time\",\"label\":\"Resolve Time\",\"sortable\":true},{\"prop\":\"value\",\"label\":\"Value\"},{\"prop\":\"message\",\"label\":\"Message\"}],\"values\":[],\"sort\":{\"prop\":\"time1\",\"order\":\"descending\"}}}]},{\"name\":\"Capacity Forecast\",\"show\":false,\"height\":200,\"mode\":\"card\",\"mbList\":[{\"key\":\"cf0001\",\"left\":0,\"top\":0,\"width\":24,\"height\":6,\"type\":\"base\",\"name\":\"Historical Storage Capacity & Prediction\",\"interval\":300,\"lastUpdate\":0,\"fontSize\":18,\"fontColor\":\"#0076ce\",\"value\":{}}]}]','2022-09-30 13:34:23',NULL);
/*!40000 ALTER TABLE `monitor_dashboard_setting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `privileges`
--

DROP TABLE IF EXISTS `privileges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `privileges` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  `description` mediumtext,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `privileges`
--

LOCK TABLES `privileges` WRITE;
/*!40000 ALTER TABLE `privileges` DISABLE KEYS */;
INSERT INTO `privileges` VALUES (1,'create',NULL,NULL,NULL),(2,'edit',NULL,NULL,NULL),(3,'view',NULL,NULL,NULL);
/*!40000 ALTER TABLE `privileges` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_privilege`
--

DROP TABLE IF EXISTS `role_privilege`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `role_privilege` (
  `id` int NOT NULL AUTO_INCREMENT,
  `privilege_id` int DEFAULT NULL,
  `role_id` int DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_privilege`
--

LOCK TABLES `role_privilege` WRITE;
/*!40000 ALTER TABLE `role_privilege` DISABLE KEYS */;
INSERT INTO `role_privilege` VALUES (1,1,1,NULL,NULL),(2,2,2,NULL,NULL),(3,3,3,NULL,NULL);
/*!40000 ALTER TABLE `role_privilege` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  `description` mediumtext,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'admin',NULL,NULL,NULL),(2,'member',NULL,NULL,NULL),(3,'guest',NULL,NULL,NULL);
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_role`
--

DROP TABLE IF EXISTS `user_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_role` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int DEFAULT NULL,
  `role_id` int DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_role`
--

LOCK TABLES `user_role` WRITE;
/*!40000 ALTER TABLE `user_role` DISABLE KEYS */;
INSERT INTO `user_role` VALUES (1,1,1,'2022-09-22 08:02:14','2022-09-22 08:02:14');
/*!40000 ALTER TABLE `user_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user` varchar(50) DEFAULT NULL,
  `password_hash` varchar(128) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'operator','pbkdf2:sha256:150000$EVGkKemQ$01609f0b7f60a674d03c6084a9885ce2d088910e6187e91e5239b114f0669ff9','2022-12-21 04:13:00','2022-12-21 04:13:00'),(2,'service','pbkdf2:sha256:150000$3JJf1G6Q$2914d8bdf62cf804efd46f26becb849e51bf20bf60f86ad3b0b59dc531c845d3','2022-12-21 04:13:01','2022-12-21 04:13:01');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-03-29  4:33:36

