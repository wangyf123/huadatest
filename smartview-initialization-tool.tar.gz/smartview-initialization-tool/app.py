import os
import json
import time
import subprocess
from flask import Flask, make_response, jsonify
from flask_cors import CORS
from flask_socketio import SocketIO, emit
from config import ProductionConfig
from flask_restx import Api, Resource, Namespace
from utils import tailf_file, verify_physical_information
from auth.api import api as auth_api
from tool.api import api as tool_api
from upgrade.api import api as upgrade_api
from unpack.api import api as unpack_api
from jsonschema import FormatChecker

from upgrade.operations import progresses


format_checker = FormatChecker()

app = Flask(__name__)
CORS(app, resources={r'/*': {'origins': '*'}}, supports_credentials=True)
api = Api(title="DeepM² Initialization Tool", format_checker=format_checker)
api.init_app(app)
socketio = SocketIO(app, cors_allowed_origins="*")

ns = Namespace("Request parameters", description="Request parameters")

# progresses = {'Upgrade Environment': '升级系统环境', 'Upgrade Docker Images': '升级Docker镜像', 'Upgrade Deployment': '升级部署'}


@ns.route("")
class RequestResource(Resource):

    def get(self):

        param_file = "parameters.json"

        if os.path.exists(param_file):
            with open(param_file) as f:
                params = json.load(f)
        else:
            params = {}

        return make_response(jsonify(params))


@socketio.on("status")
def handle_status(data=None):
    if data and data.get("step") == "upgrade":
        status_file = app.config.get("UPGRADE_STATUS_FILE")
    else:
        status_file = app.config.get("INITIAL_STATUS_FILE")

    while True:

        if not os.path.exists(status_file):
            time.sleep(1)
            continue
        with open(status_file) as f:
            try:
                data = json.load(f)
            except Exception as e:
                time.sleep(1)
                print(str(e))				
                continue

        emit("status", {"data": data})

        time.sleep(1)
        if data["overall"] == "done":
           break


@socketio.on("log")
def handle_log(data=None):

    if data and data.get("step") == "upgrade":
        log_path = app.config.get("UPGRADE_LOG_PATH")
    else:
        log_path = app.config.get("INITIAL_LOG_PATH")

    if not os.path.exists(log_path):
        emit("log", {"data": 'No log content'})
        return

    with open(log_path) as f:
        lines = f.readlines()

    for line in lines:
        emit("log", {"data": line})

    with open(log_path) as f:
        while True:
            new_lines = tailf_file(f)
            for line in new_lines:
                emit("log", {"data": line})


@app.route("/verify")
def verify():

    return verify_physical_information()


def create_app():

    app.config.from_object(ProductionConfig)
    api.add_namespace(auth_api, path="/auth")
    api.add_namespace(tool_api, path="/setup")
    api.add_namespace(upgrade_api, path="/upgrade")
    api.add_namespace(unpack_api, path="/unpack")
    api.add_namespace(ns, path="/parameters")

    CORS(app, resources={r'/*': {'origins': '*'}}, supports_credentials=True)


if __name__ == "__main__":
    create_app()
    socketio.run(app, host="0.0.0.0", port=app.config.get("LISTEN_PORT", 5000), allow_unsafe_werkzeug=True)


